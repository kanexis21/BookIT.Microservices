﻿namespace SapportService.Core.Domain.Models
{
    public class MessageSenderType
    {
    }
}
