﻿using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using SupportService.Core.Application.Common;
using SupportService.Core.Application.Interfaces;
using SupportService.Core.Application.Services.Clients;
using SupportService.Infrastructure;
using System.Reflection;

namespace SupportService.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services)
        {
            services.AddHttpClient<IUserClient,  UserClient>("IdentityServer", options =>
            {
                options.BaseAddress = new Uri("https://localhost:5005");
            });
            services.AddSingleton<IUserClient,UserClient>();
            services.AddMediatR(cfg =>
                 cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly()));

            services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(ValidatorBehavior<,>));

            return services;
        }

    }
}
